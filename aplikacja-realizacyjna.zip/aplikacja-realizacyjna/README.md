# Aplikacja Realizacyjna
Aplikacja Webowa służąca do zarządzania projektami dla małych i średnich firm/wydziałów w dużych firmach.

Projekt zaliczeniowy na zajęcia "Praca Grupowa" w SAN w Warszawie.

Semestr IV  
Rok 22/23
