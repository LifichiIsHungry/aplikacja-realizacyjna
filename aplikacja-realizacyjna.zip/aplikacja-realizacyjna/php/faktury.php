<?php
require("lib/db.php");
require("lib/functions.php");
require("lib/check_session.php");

if(isset($_REQUEST["oplacona"])) {
    $faktura_id = $_REQUEST["oplacona"];
    $date = date('Y-m-d');

    $smt = $db->prepare("UPDATE Faktura SET realny_termin_zaplaty=:realny_termin_zaplaty WHERE id=:id");
    $smt->execute(["realny_termin_zaplaty" => $date, "id" => $faktura_id]);

    $smt = $db->prepare("SELECT projekt FROM Faktura WHERE id=:id");
    $smt->execute(["id" => $faktura_id]);
    $projekt_id = $smt->fetch()["projekt"];

    header("Location: /php/faktury.php?id=".$projekt_id);
    exit();
}

if(!isset($_REQUEST["id"])) {
    header("Location: /php/projekty.php");
}

$doc = new DOMDocument();
$doc->loadHTML(file_get_contents("./html/faktury/faktury.html"));

// Fetch data
$smt = $db->prepare("SELECT Projekt.nazwa,Faktura.nazwa,Faktura.termin_zaplaty,Faktura.realny_termin_zaplaty,Faktura.uwagi,Faktura.id FROM Projekt INNER JOIN Faktura ON Faktura.projekt = Projekt.id WHERE Projekt.id = :pid");
$smt->execute(["pid" => $_REQUEST["id"]]);

foreach($smt->fetchAll() as $faktura) {
    $html_faktura = "
    <tr>
        <td>".$faktura[0]."</td>
        <td>".$faktura[1]."</td>
        <td>".$faktura[2]."</td>
        <td>".$faktura[3]."</td>
        <td>".$faktura[4]."</td>
        <td><button class=\"secondaryBtn\" onclick=\"location.href = '/php/faktury.php?oplacona=".$faktura[5]."'\">Ozn.jako opłacona</button></td>
    </tr>
    ";

    append_html_to_element($doc, $doc->getElementById("table-body-faktura"), $html_faktura);
}

echo($doc->saveHTML());