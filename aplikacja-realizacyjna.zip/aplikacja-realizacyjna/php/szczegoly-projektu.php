<?php
require("lib/db.php");
require("lib/functions.php");
require("lib/check_session.php");

if(!isset($_REQUEST["id"])) {
    header("Location: /php/projekty.php");
}

$doc = new DOMDocument();
$doc->loadHTML(file_get_contents("./html/projekty-otwarte/projekty.html"));

$smt = $db->prepare("SELECT * FROM Projekt WHERE id=:id");
$smt->execute(["id" => $_REQUEST["id"]]);
$project = $smt->fetch();
if ($project == false) {
    header("Location: /php/projekty.php");
}

append_html_to_element($doc, $doc->getElementById("panel-aside"),
"<h2>".$project["nazwa"]."</h2>
<div class=\"aside-nav\" >
    <a href=\"/php/szczegoly-projektu.php?id=".$project["id"]."\" class=\"active\">Usługi</a>
    <a href=\"/php/faktury.php?id=".$project["id"]."\">Faktury</a>
    <a href=\"/php/projektyInfo.php?id=".$project["id"]."\">Informacje o projekcie</a>
</div>
");

$smt = $db->prepare("SELECT Usluga.nazwa,Usluga.planowane_zakonczenie,Usluga.planowany_koszt,Usluga.uwagi,Usluga.id FROM Usluga WHERE Usluga.projekt = :id_projektu");
$smt->execute(["id_projektu" => $_REQUEST["id"]]);

foreach($smt->fetchAll() as $usluga) {
    $html_usluga = "
    <tr>
        <td>".$usluga[0]."</td>
        <td>".$usluga[1]."</td>
        <td>".$usluga[2]."</td>
        <td>".$usluga[3]."</td>
        <td><button class=\"secondaryBtn\" onclick=\"location.href = '/php/dodajFakture.php?id=".$usluga["id"]."'\">Wystaw fakture</button></td>
    </tr>
    ";

    append_html_to_element($doc, $doc->getElementById("table-body-projekty"), $html_usluga);
}

echo($doc->saveHTML());