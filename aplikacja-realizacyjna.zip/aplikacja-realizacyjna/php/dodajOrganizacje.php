<?php
require("lib/db.php");
require("lib/check_session.php");
require("lib/functions.php");

$doc = new DOMDocument();
$doc->loadHTML(file_get_contents("./html/dodajOrganizacje/dodajOrganizacje.html"));

// Don't display site, add new project
// and reditect to /php/pracownicy.php
if (isset($_REQUEST["add_organization"])) {
    $values = array();
    $values["nazwa"] = $_REQUEST["nazwa"];
    $values["nip"] = $_REQUEST["nip"];
    $values["adres"] = $_REQUEST["adres"];
    $values["email"] = $_REQUEST["email"];
    $values["telefon"] = $_REQUEST["telefon"];

    $stmt = $db->prepare("INSERT INTO Organizacja(nazwa,nip,adres,email,telefon) VALUES (:nazwa,:nip,:adres,:email,:telefon);");

    $stmt->execute($values);
    header("Location: /php/organizacje.php");
}

// Display site

echo($doc->saveHTML());

