<?php
require("lib/db.php");
require("lib/check_session.php");
require("lib/functions.php");

if(isset($_REQUEST["add_faktura"])) {
    $usluga_id = $_REQUEST["service"];
    $smt = $db->prepare("SELECT * FROM Usluga WHERE id = :id");
    $smt->execute(["id" => $usluga_id]);
    $usluga = $smt->fetch();

    $values = array();
    $values["projekt"] = $usluga["projekt"];
    $values["nazwa"] = $usluga["nazwa"];
    $values["data_wystawienia"] = $_REQUEST["creationDate"];
    $values["termin_zaplaty"] = $_REQUEST["plannedPayDate"];
    $values["realny_termin_zaplaty"] = null;
    // $values["uniewazniona"] = $_REQUEST["plannedPayDate"];
    $values["uwagi"] = $_REQUEST["comments"];
    $values["wartosc_faktury"] = $usluga["planowany_koszt"];

    $stmt = $db->prepare("INSERT INTO Faktura(
        projekt,
        nazwa,
        data_wystawienia,
        termin_zaplaty,
        realny_termin_zaplaty,
        uniewazniona,
        uwagi,
        wartosc_faktury
    ) VALUES (
        :projekt,
        :nazwa,
        :data_wystawienia,
        :termin_zaplaty,
        :realny_termin_zaplaty,
        false,
        :uwagi,
        :wartosc_faktury
    );");

    $stmt->execute($values);

    $stmt2 = $db->prepare("UPDATE Usluga SET realne_zakonczenie=:realne_zakonczenie WHERE id=:id");

    $stmt2->execute([
        "realne_zakonczenie" => $_REQUEST["creationDate"],
        "id" => $usluga_id]
    );

    header("Location: /php/szczegoly-projektu.php?id=".$values["projekt"]);
    exit();
}

if(!isset($_REQUEST["id"])) {
    header("Location: /php/projekty.php");
    exit();
}

$doc = new DOMDocument();
$doc->loadHTML(file_get_contents("./html/dodajFakture/dodajFakture.html"));

$smt = $db->prepare("SELECT * FROM Usluga WHERE id = :id");
$smt->execute(["id" => $_REQUEST["id"]]);
$usluga = $smt->fetch();
if ($usluga == false) {
    header("Location: /php/projekty.php");
    exit();
}

append_html_to_element($doc, $doc->getElementById("service"),
    "<option value=\"".$usluga["id"]."\" selected=\"true\">".$usluga["nazwa"]."</option>");

echo($doc->saveHTML());