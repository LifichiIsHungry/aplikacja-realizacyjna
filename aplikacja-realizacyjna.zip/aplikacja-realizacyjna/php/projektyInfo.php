<?php
require("lib/db.php");
require("lib/functions.php");
require("lib/check_session.php");

if(!isset($_REQUEST["id"])) {
    header("Location: /php/projekty.php");
}

$doc = new DOMDocument();
$doc->loadHTML(file_get_contents("./html/projekty-otwarte/projektyInfo.html"));

$smt = $db->prepare("SELECT * FROM Projekt WHERE id=:id");
$smt->execute(["id" => $_REQUEST["id"]]);
$project = $smt->fetch();
if ($project == false) {
    header("Location: /php/projekty.php");
}

append_html_to_element($doc, $doc->getElementById("panel-aside"),
"<h2>".$project["nazwa"]."</h2>
<div class=\"aside-nav\" >
    <a href=\"/php/szczegoly-projektu.php?id=".$project["id"]."\" >Usługi</a>
    <a href=\"/php/faktury.php?id=".$project["id"]."\">Faktury</a>
    <a href=\"/php/projektyInfo.php?id=".$project["id"]."\" class=\"active\">Informacje o projekcie</a>
</div>
");
// Fetch data
 //$smt = $db->prepare("SELECT Projekt.status_realizacji,Usluga.nazwa,Usluga.planowane_zakonczenie,Usluga.planowany_koszt FROM Usluga INNER JOIN Projekt ON Projekt.id = Usluga.projekt WHERE Usluga.projekt = Projekt.id ");
 //$smt->execute();

 //Projekt.nazwa,rozpoczecie,Projekt.planowane_zakonczenie,Projekt.przewidywane_zyski,Projekt.przewidywane_koszta,Projekt.kary_umowne

$smt = $db->prepare("SELECT Organizacja.nazwa,Projekt.rozpoczecie,Projekt.planowane_zakonczenie,Projekt.przewidywane_zyski,Projekt.przewidywane_koszta,Projekt.kary_umowne,Organizacja.id FROM Projekt Inner Join Organizacja ON Organizacja.id = Projekt.organizacja WHERE Projekt.id = :id_projektu");
$smt->execute(["id_projektu" => $_REQUEST["id"]]);


foreach($smt->fetchAll() as $projekt) {
    $html_projekt = "
    <tr>
        <td>".$projekt[0]."</td>
        <td>".$projekt[1]."</td>
        <td>".$projekt[2]."</td>
        <td>".$projekt[3]."</td>
        <td>".$projekt[4]."</td>
        <td>".$projekt[5]."</td>
    </tr>
    ";

    append_html_to_element($doc, $doc->getElementById("table-body-info"), $html_projekt);
}

echo($doc->saveHTML());