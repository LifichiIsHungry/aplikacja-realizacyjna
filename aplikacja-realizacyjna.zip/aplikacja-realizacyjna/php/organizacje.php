<?php
require("lib/db.php");
require("lib/functions.php");
require("lib/check_session.php");

$doc = new DOMDocument();
$doc->loadHTML(file_get_contents("./html/organizacje/organizacje.html"));

// Fetch data
$smt = $db->prepare("SELECT * FROM Organizacja ");
$smt->execute();

foreach($smt->fetchAll() as $organizacja) {
    $html_organizacja = "
    <tr>
        <td>".$organizacja[1]."</td>
        <td>".$organizacja[2]."</td>
        <td>".$organizacja[3]."</td>
        <td>".$organizacja[4]."</td>
        <td>".$organizacja[5]."</td>
        
    </tr>
    ";

    append_html_to_element($doc, $doc->getElementById("table-body-organizacje"), $html_organizacja);
}

echo($doc->saveHTML());